import { CONFIG, DATA_ATTRIBUTES, ERROR_MESSAGES } from "./constants"
import type { ConversionError, ConversionOptions, ConversionResult } from "./types"
import { isHEVCSupported } from "./webcodecs-hevc"


// ─── Magic-bytes helpers ────────────────────────────────────────────────────

const HEIC_BRANDS_SINGLE = new Set(["mif1", "heic", "heix"])
const HEIC_BRANDS_SEQUENCE = new Set(["msf1", "hevc", "hevx"])

// ─── Types ───────────────────────────────────────────────────────────────────


function getHeicBrand(buffer: ArrayBuffer): string {
  if (buffer.byteLength < 12) return ""
  const bytes = new Uint8Array(buffer, 8, 4)
  return String.fromCharCode(...Array.from(bytes))
    .replace(/\0/g, " ")
    .trim()
}

function isHeicBuffer(buffer: ArrayBuffer): boolean {
  const brand = getHeicBrand(buffer)
  return HEIC_BRANDS_SINGLE.has(brand) || HEIC_BRANDS_SEQUENCE.has(brand)
}

function isAnimatedHeicBuffer(buffer: ArrayBuffer): boolean {
  return HEIC_BRANDS_SEQUENCE.has(getHeicBrand(buffer))
}

import hardWorkerUrl from "./heic-worker-hard.ts?worker&url"
import softWorkerUrl from "./heic-worker-soft.ts?worker&url"

export type CacheEntry =
  | { type: "single"; url: string }
  | { type: "animated"; frames: Array<{ url: string; durationMs: number }> }

// ─── Converter ──────────────────────────────────────────────────────────────

/**
 * HEIC converter: handles single-frame and animated (sequence) HEIC/HEIF files.
 */
export class HEICConverter {
  private processedImages = new WeakSet<HTMLImageElement>()
  /** Prevents duplicate concurrent conversions of the same element. */
  private processingQueue = new Map<HTMLImageElement, Promise<ConversionResult>>()
  /** Cache: original src → converted blob URL or frames. */
  private urlCache = new Map<string, CacheEntry>()
  /** Animation interval IDs keyed by the image element. */
  private animationTimers = new Map<HTMLImageElement, ReturnType<typeof setInterval>>()
  private workerPromise: Promise<Worker>
  private workerTaskId = 0
  private workerCallbacks = new Map<number, { resolve: (val: any) => void; reject: (err: any) => void }>()

  constructor() {
    this.workerPromise = this.initWorker()
  }

  private async initWorker(): Promise<Worker> {
    const supported = await isHEVCSupported()
    console.log("supported:"+supported+", hardWorkerUrl:" + hardWorkerUrl+", softWorkerUrl:"+softWorkerUrl)
    const worker = new Worker(supported ? hardWorkerUrl : softWorkerUrl, { type: "module" })

    worker.onmessage = (e) => {
      const { id, success, error, type, url, frames, width, height } = e.data
      const callbacks = this.workerCallbacks.get(id)
      if (callbacks) {
        if (success) {
          callbacks.resolve({ type, url, frames, width, height })
        } else {
          callbacks.reject(new Error(error))
        }
        this.workerCallbacks.delete(id)
      }
    }
    return worker
  }


  // ── LRU Cache helpers ───────────────────────────────────────────────────

  private getCacheEntry(key: string): CacheEntry | undefined {
    if (!this.urlCache.has(key)) return undefined
    const entry = this.urlCache.get(key)!
    // LRU: 访问时重新插入到 Map 尾部（最近使用）
    this.urlCache.delete(key)
    this.urlCache.set(key, entry)
    return entry
  }

  private setCacheEntry(key: string, entry: CacheEntry): void {
    if (this.urlCache.has(key)) {
      this.urlCache.delete(key)
    } else {
      // 容量满时，基于 Map 按插入顺序迭代的特性，先淘汰最旧的元素，再增加新元素
      while (this.urlCache.size >= CONFIG.MAX_CACHE_ITEMS) {
        const oldestKey = this.urlCache.keys().next().value
        if (oldestKey) {
          const oldestEntry = this.urlCache.get(oldestKey)
          if (oldestEntry) {
            if (oldestEntry.type === "single") {
              URL.revokeObjectURL(oldestEntry.url)
            } else {
              oldestEntry.frames.forEach((f) => URL.revokeObjectURL(f.url))
            }
          }
          this.urlCache.delete(oldestKey)
          console.debug(`LRU Cache: evicted ${oldestKey}`)
        } else {
          break
        }
      }
    }
    this.urlCache.set(key, entry)
  }

  // ── Internal helpers ────────────────────────────────────────────────────

  private isImageProcessed(img: HTMLImageElement): boolean {
    return this.processedImages.has(img) || img.hasAttribute(DATA_ATTRIBUTES.PROCESSED)
  }

  private markImageAsProcessed(img: HTMLImageElement): void {
    this.processedImages.add(img)
    img.setAttribute(DATA_ATTRIBUTES.PROCESSED, "true")
  }

  /**
   * Resets the processed state of an image element so it can be re-converted.
   * Called when an img's src attribute changes to a new HEIC URL.
   */
  resetImageProcessed(img: HTMLImageElement): void {
    this.processedImages.delete(img)

    // 1. Clear animation timer for this specific image
    if (this.animationTimers.has(img)) {
      clearInterval(this.animationTimers.get(img)!)
      this.animationTimers.delete(img)
    }

    // Note: We DO NOT revoke object URLs here. `urlCache` maps the original URL to the 
    // converted Blob URL. If we revoke it here when one img node changes its src, 
    // it will break ANY OTHER img node on the page that is displaying the same HEIC image, 
    // and defeats the purpose of `urlCache`. Object URLs are released globally in `cleanup()`.

    img.removeAttribute(DATA_ATTRIBUTES.PROCESSED)
    img.removeAttribute(DATA_ATTRIBUTES.ORIGINAL_SRC)
    // Clean up any lingering state classes so the new conversion starts fresh
    img.classList.remove("heic-processing", "heic-converted")
  }

  /**
   * Fetches raw image bytes.  Validates size and HEIC magic bytes.
   * If the server returns a correct HEIC MIME type but the URL has no .heic
   * extension, we still accept the blob.
   */
  private async fetchImageData(src: string): Promise<ArrayBuffer> {
    let response: Response
    try {
      response = await fetch(src)
    } catch (error: any) {
      if (error.name === "TypeError") {
        // TypeError from fetch can mean CORS blocked or a generic network failure
        // (DNS, offline, etc.).  Use origin comparison as a best-effort heuristic:
        // a cross-origin request failing with TypeError is most likely CORS;
        // a same-origin TypeError is a plain network failure.
        let isCrossOrigin = false
        try { isCrossOrigin = new URL(src).origin !== location.origin } catch { /* ignore */ }
        throw new Error(isCrossOrigin ? ERROR_MESSAGES.CORS_ERROR : ERROR_MESSAGES.NETWORK_ERROR)
      }
      throw new Error(ERROR_MESSAGES.NETWORK_ERROR)
    }

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`)
    }

    const blob = await response.blob()

    if (blob.size > CONFIG.MAX_FILE_SIZE) {
      throw new Error(ERROR_MESSAGES.FILE_TOO_LARGE)
    }

    const buffer = await blob.arrayBuffer()

    // Accept if magic bytes confirm HEIC, or if the MIME type is heic/heif.
    const mimeOk =
      blob.type === "image/heic" ||
      blob.type === "image/heif" ||
      blob.type === "image/heic-sequence" ||
      blob.type === "image/heif-sequence"

    if (!isHeicBuffer(buffer) && !mimeOk) {
      throw new Error(ERROR_MESSAGES.INVALID_FORMAT)
    }

    return buffer
  }



  /**
   * Starts an animation loop by cycling the img.src through pre-decoded object URLs.
   */
  private setupUrlAnimation(
    img: HTMLImageElement,
    frames: Array<{ url: string; durationMs: number }>
  ): void {
    let frameIndex = 0

    const drawFrame = () => {
      img.src = frames[frameIndex].url
      frameIndex = (frameIndex + 1) % frames.length
    }

    // Draw first frame immediately
    drawFrame()

    // Use average frame duration as the interval (HEIC sequences are usually uniform)
    const avgDurationMs =
      frames.reduce((sum, f) => sum + f.durationMs, 0) / frames.length
    const timerId = setInterval(drawFrame, Math.max(16, Math.round(avgDurationMs)))
    this.animationTimers.set(img, timerId)

    this.markImageAsProcessed(img)
  }

  // ── Public API ──────────────────────────────────────────────────────────

  /**
   * Converts a single <img> element from HEIC/HEIF to a displayable format.
   * De-duplicates concurrent calls for the same element via processingQueue.
   */
  async convertImage(
    img: HTMLImageElement,
    options: ConversionOptions = {}
  ): Promise<ConversionResult> {
    if (this.isImageProcessed(img)) {
      return { success: true }
    }

    // De-duplicate: if already in-flight, reuse the same promise
    if (this.processingQueue.has(img)) {
      return this.processingQueue.get(img)!
    }

    const task = this._doConvert(img, options)
    this.processingQueue.set(img, task)
    try {
      return await task
    } finally {
      this.processingQueue.delete(img)
    }
  }

  private async _doConvert(
    img: HTMLImageElement,
    options: ConversionOptions = {}
  ): Promise<ConversionResult> {
    const originalSrc: string = img.src
    const regex = /(https|http).*?\.(heic|heif)/gi
    const cacheKey = originalSrc.match(regex)?.[0] || originalSrc

    const { maxRetries = CONFIG.RETRY_ATTEMPTS } = options

    // Persist original src for error-recovery click handlers
    if (!img.hasAttribute(DATA_ATTRIBUTES.ORIGINAL_SRC)) {
      img.setAttribute(DATA_ATTRIBUTES.ORIGINAL_SRC, originalSrc)
    }

    // Reuse an already-converted blob URL or frames for this src
    const cachedEntry = this.getCacheEntry(cacheKey)
    console.debug('get cacheKey:' + cacheKey + ', cachedEntry:', cachedEntry)

    if (cachedEntry) {
      if (cachedEntry.type === "single") {
        img.src = cachedEntry.url
        img.classList.add("heic-converted")
        this.markImageAsProcessed(img)
      } else if (cachedEntry.type === "animated") {
        this.setupUrlAnimation(img, cachedEntry.frames)
        img.classList.add("heic-converted")
      }
      return { success: true }
    }

    img.classList.add("heic-processing")

    let lastError: any
    for (let attempt = 0; attempt < maxRetries; attempt++) {
      try {
        const buffer = await this.fetchImageData(originalSrc)
        const bufferType = isAnimatedHeicBuffer(buffer)? "animated":"single"
        const taskId = this.workerTaskId++
        const worker = await this.workerPromise
        const workPromise = new Promise<any>((resolve, reject) => {
          this.workerCallbacks.set(taskId, { resolve, reject })
          worker.postMessage({ id: taskId, buffer, options, type: bufferType }, [buffer])
        })

        const workerResult = await workPromise

        if (workerResult.success === false) {
          throw new Error(workerResult.error || "Worker error")
        }

        if (workerResult.type === "animated") {
          this.setCacheEntry(cacheKey, { type: "animated", frames: workerResult.frames })
          this.setupUrlAnimation(img, workerResult.frames)
          img.classList.remove("heic-processing")
          img.classList.add("heic-converted")
          return { success: true }
        }

        if (workerResult.type === "single") {
          // ── Single-frame path ──────────────────────────────────────────
          const objectURL = workerResult.url

          this.setCacheEntry(cacheKey, { type: "single", url: objectURL })
          console.debug('set cacheKey:' + cacheKey + ', objectURL:' + objectURL)

          img.src = objectURL
          img.classList.remove("heic-processing")
          img.classList.add("heic-converted")
          this.markImageAsProcessed(img)

          return { success: true }          
        }

      } catch (error: any) {
        lastError = error
        console.warn(`HEIC转换尝试 ${attempt + 1}/${maxRetries} 失败:`, error.message)

        if (attempt < maxRetries - 1) {
          await new Promise((resolve) => setTimeout(resolve, 1000 * (attempt + 1)))
        }
      }
    }

    return this.handleConversionError(img, lastError, originalSrc)
  }

  /**
   * Batch-processes a list of images with concurrency throttling.
   */
  async convertAllImages(
    images: NodeListOf<HTMLImageElement> | HTMLImageElement[],
    options: ConversionOptions = {}
  ): Promise<ConversionResult[]> {
    const results: ConversionResult[] = []
    const imageArray = Array.from(images)

    for (let i = 0; i < imageArray.length; i += CONFIG.MAX_CONCURRENT) {
      const batch = imageArray.slice(i, i + CONFIG.MAX_CONCURRENT)
      const settled = await Promise.allSettled(batch.map((img) => this.convertImage(img, options)))

      settled.forEach((result) => {
        if (result.status === "fulfilled") {
          results.push(result.value)
        } else {
          results.push({
            success: false,
            error: {
              type: "unknown",
              message: result.reason?.message ?? "Promise rejected",
            },
          })
        }
      })
    }

    return results
  }

  /**
   * Releases all blob URLs and stops animation timers.
   */
  cleanup(): void {
    this.urlCache.forEach((entry) => {
      if (entry.type === "single") {
        URL.revokeObjectURL(entry.url)
      } else {
        entry.frames.forEach(f => URL.revokeObjectURL(f.url))
      }
    })
    this.urlCache.clear()
    this.processingQueue.clear()
    this.animationTimers.forEach((id) => clearInterval(id))
    this.animationTimers.clear()
    this.workerPromise.then(worker => worker.terminate())
  }

  // ── Error handling ──────────────────────────────────────────────────────

  private handleConversionError(
    img: HTMLImageElement,
    error: any,
    originalSrc: string
  ): ConversionResult {
    img.classList.remove("heic-processing")
    img.classList.add("heic-converted")

    let errorType: ConversionError["type"] = "unknown"
    let errorMessage: string = error?.message ?? ERROR_MESSAGES.CONVERSION_FAILED
    let displayMessage = errorMessage

    if (
      errorMessage.includes("CORS") ||
      errorMessage.includes("cross-origin") ||
      errorMessage.includes("Access-Control-Allow-Origin")
    ) {
      errorType = "cors"
      errorMessage = ERROR_MESSAGES.CORS_ERROR
      displayMessage = "跨域访问被拒绝"
    } else if (errorMessage.includes("Failed to fetch") || errorMessage.includes("网络")) {
      errorType = "network"
      errorMessage = ERROR_MESSAGES.NETWORK_ERROR
      displayMessage = "网络请求失败"
    } else if (errorMessage.includes("50MB")) {
      errorType = "size"
      displayMessage = "文件过大"
    } else if (errorMessage.includes("格式") || errorMessage.includes("HEIC")) {
      errorType = "format"
      displayMessage = "格式不支持"
    } else if (errorMessage.includes("转换")) {
      errorType = "conversion"
      displayMessage = "转换失败"
    } else if (error?.name === "AbortError") {
      errorType = "network"
      displayMessage = "请求超时"
    }

    img.onclick = (e: MouseEvent) => {
      e.preventDefault()
      if (errorType === "cors") {
        const confirmed = confirm(
          `图片因跨域限制无法转换。\n\n错误详情: ${displayMessage}\n\n是否在新窗口中查看原图？`
        )
        if (confirmed) window.open(originalSrc, "_blank")
      } else {
        window.open(originalSrc, "_blank")
      }
    }

    console.warn("🔴 HEIC转换失败:", {
      src: originalSrc,
      type: errorType,
      message: errorMessage,
      originalError: error,
    })

    return { success: false, error: { type: errorType, message: errorMessage, originalError: error } }
  }
}

