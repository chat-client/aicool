import * as heicDecode from "heic-decode"
import { CONFIG } from "./constants"
import type { ConversionOptions } from "./types"

// ─── Types for heic-decode fallback ──────────────────────────────────────────

interface DecodedFrameData {
  width: number
  height: number
  data: Uint8ClampedArray
}

interface HeicDecodeFrame {
  width: number
  height: number
  decode: () => Promise<DecodedFrameData>
}
type HeicDecodeFrameList = HeicDecodeFrame[] & { dispose?: () => void }

// ─── Worker Logic ─────────────────────────────────────────────────────────────

self.onmessage = async (e: MessageEvent) => {
  const { id, buffer, options, type} = e.data
  const byteArray = new Uint8Array(buffer);
  console.log('soft Worker 收到消息:', id)
  try {
    if (type === "animated"){
      const animatedResult = await processAnimated(byteArray, options)
      if (animatedResult) {
        self.postMessage(
          {
            id,
            success: true,
            type: "animated",
            frames: animatedResult.frames,
            width: animatedResult.width,
            height: animatedResult.height,
          }
        )
        return
      }
      // If animated processing returns null, fall through to single frame
    }
    console.log('soft Worker processSingleFrame:', id)
    const url = await processSingleFrame(byteArray, options)
    if(!url){
      throw new Error("Worker HEIC帧解码失败")
    }
    self.postMessage({ id, success: true, type: "single", url })
  } catch (error: any) {
    self.postMessage({ id, success: false, error: error.message || String(error) })
  }
}


async function processSingleFrame(buffer: Uint8Array, options: ConversionOptions): Promise<string> {
  try {
    const decodeOne: (opts: { buffer: Uint8Array }) => Promise<DecodedFrameData> =
      (heicDecode as any).default ?? (heicDecode as any)

    if (typeof decodeOne !== "function") {
      throw new Error("heic-decode.default not available")
    }
    const frame: DecodedFrameData = await decodeOne({ buffer })
    if (!frame) {
      throw new Error("No frame decoded")
    }
    const imageData = new ImageData(frame.data as any, frame.width, frame.height)
    const canvas = new OffscreenCanvas(frame.width, frame.height)
    const ctx = canvas.getContext("2d")!
    ctx.putImageData(imageData, 0, 0)
    const blob = await canvas.convertToBlob({ type: "image/png" })
    return URL.createObjectURL(blob) 
  } catch (err) {
    console.warn("⚠️ Worker HEIC帧解码失败", err)
    return null
  }
}

async function processAnimated(
  buffer: Uint8Array,
  options: ConversionOptions
): Promise<{ frames: Array<{ url: string; durationMs: number }>; width: number; height: number } | null> {
  try {
    const decodeAll: (opts: { buffer: Uint8Array }) => Promise<HeicDecodeFrameList> =
      (heicDecode as any).default?.all ?? (heicDecode as any).all

    if (typeof decodeAll !== "function") {
      throw new Error("heic-decode.all not available")
    }

    const frames: HeicDecodeFrameList = await decodeAll({ buffer })

    if (!frames || frames.length === 0) {
      throw new Error("No frames decoded")
    }

    if (frames.length === 1) {
      frames.dispose?.()
      return null
    }

    const rawFrames = await Promise.all(frames.map((f) => f.decode()))
    frames.dispose?.()

    const { width, height } = rawFrames[0]

    // Convert raw ImageDatas to objectURLs
    const urlFrames = await Promise.all(
      rawFrames.map(async (f) => {
        const imageData = new ImageData(f.data as any, f.width, f.height)
        const canvas = new OffscreenCanvas(f.width, f.height)
        const ctx = canvas.getContext("2d")!
        ctx.putImageData(imageData, 0, 0)
        const blob = await canvas.convertToBlob({ type: "image/png" })
        return { url: URL.createObjectURL(blob), durationMs: Math.round(1000 / CONFIG.ANIMATION_FPS) } // Fallback to config FPS
      })
    )

    return { frames: urlFrames, width, height }
  } catch (err) {
    console.warn("⚠️ Worker 动画HEIC帧解码失败，回退到静态首帧:", err)
    return null
  }
}
